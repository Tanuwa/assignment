var readlineSync = require('readline-sync');
var userName = readlineSync.question('May I have your name? ');
console.log('Hi ' + userName + '!');
//ask user for name and give greeting



var enemies = ['Dragon', 'Predator', 'Alien'];
var inventory = {
    health: 100,
    items: []
};
var walkCount=0;

function Enemy(name) {
    this.name = name;
}

function walk() {
    if(walkCount < 5 && inventory.health > 0){
    console.log("would you pls push W");
    var key = readlineSync.question('Press W to walk ');
    var countR = Math.floor(Math.random() * 5) + 1;
    if (key === 'w') {
        walkCount++;
        console.log("good job");
        if (countR === 1) {
            fight();
        } else {
            console.log("you did not meet the moster");
            if(walkCount<5 && inventory.health >0){
            walk();
            }
            else{
                win();
            }
        }

    } else {
        console.log("Press correct key - W");
    }
    }
    else {
        win();
    }

}

function run() {
    var yourLuck = Math.floor(Math.random() * 2 + 1);
    console.log("lucky "+yourLuck);
    if (yourLuck == 1) {
        
        console.log("You escape, you can continue walking");
        walk();
    } else {
        var fightingEnemy = enemies[Math.floor(Math.random() * enemies.length)];
        attackEnemy(fightingEnemy);
    }
}

function fight() {
    // ask user to either fight or run
    var decision = readlineSync.question('run or fight ');
    if (decision === 'run') {
        run();
    } else if (decision === 'fight') {
        var fightingEnemy = new Enemy(enemies[Math.floor(Math.random() * enemies.length)]);
        attackEnemy(fightingEnemy.name);
    }
}


function attackEnemy(fightingEnemy) {
    var killornot = Math.floor(Math.random() * 2 + 1);
    console.log("killornot "+ killornot);
    if (killornot === 1) {
        enemyDie(fightingEnemy);
        walk();
    } else {
        enemyAttack();
        console.log("enemy attacked");
    }
}

function enemyAttack() {
    var dmg = Math.floor(Math.random() * 40) + 10;
    inventory.health = inventory.health - dmg;
    console.log("your health "+ inventory.health +'%');
    if (inventory.health > 0) {
        walk();
    } else {
        die();
    }
}

function die() {
    console.log("Sorry game is over");
}

function enemyDie(fightingEnemy) {
    enemies.splice(enemies.indexOf(fightingEnemy), 1);
    inventory.items.push(fightingEnemy);
    console.log("we killed enemy " + fightingEnemy);
}
function win(){
    console.log("congrats you win the game");
    return;
}



    walk();



//Health for enemies and characters
//
//
//Items
//
//after winning fight, continue walking, until you win the game or lose all your health.



